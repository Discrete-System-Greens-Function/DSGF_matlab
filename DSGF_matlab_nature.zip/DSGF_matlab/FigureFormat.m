classdef FigureFormat
	enumeration
		fig, png, jpg
	end
end
