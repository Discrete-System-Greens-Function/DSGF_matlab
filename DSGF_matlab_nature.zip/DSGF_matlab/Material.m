classdef Material
	enumeration
		SiO2, SiC, SiN, user_defined
	end
end
