classdef CalculationOption
	enumeration
		direct, iterative
	end
end
