%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Lindsay Walter
% u0928979
% System Green's Function Approach to T-DDA
% Updated 3/3/22
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear, clc, close all
format long
profile on
disp(['Running MATLAB script ' mfilename])
tic

% This code implements the Discrete System Green's Function approach (DSGF)
% to solve for the heat transfer between two bulk spheres.  Two methods are
% used: 
%   (1) The iterative method outlined in O. J. F. Martin, C. Girard, 
%       and A. Dereux, Generalized Field Propagator for Electromagnetic Scattering
%       and Light Confinement, Phys. Rev. Lett. 74, 526 (1995).
%   (2) Direct matrix inversion of the entire system of equations.
%


%%%%%%%%%%%%%
% Constants %
%%%%%%%%%%%%%

q = 1.60218e-19;            % Number of joules per eV [J/eV]
h_bar = 1.0545718e-34;      % Planck's constant [J*s]
k_b = 1.38064852e-23;       % Boltzmann constant [J/K]
epsilon_0 = 8.8542e-12;     % Permittivity of free space [F/m]
mu_0 = (4*pi)*(10^-7);      % Permeability of free space [H/m]
c_0 = 299792458;            % Speed of light in vacuum [m/s]


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%******************************USER INPUTS********************************%

%%%%%%%%%%%%%%%%%%%%%%
% Set results export %
%%%%%%%%%%%%%%%%%%%%%%

% Directory where results files will be saved (string)
saveDir = 'Results'; % This directory has already been created within the code directory

% File name of .mat saved variables
current_time = fix(clock);  % Date and time
description = '2_spheres';  % Very short description of results
file_name_saved = ['results_' description '_' date '_' num2str(current_time(4)) '-' num2str(current_time(5)) '-' num2str(current_time(6)) ]; % File name where results will be saved

% Save outputs in .mat file after the full code runs? (0 = "no", 1 = "yes")
save_var_mat = 1;

% Save figures? (0 = "no", 1 = "yes")
save_fig = 1;


%%%%%%%%%%%%%%%%%%%%%
% Show figure axes? %
%%%%%%%%%%%%%%%%%%%%%

% 0: Do not show figure axes for 3D plots
% 1: Show figure axes for 3D plots

show_axes = 1;


%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Set calculation options %
%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Calculation approach
% 'direct' = direct matrix inversion using 'mldivide' operator
% 'iterative' = column-wise iterative solver (bicgstab) without full matrix storage. (THIS IS NOT IMPLEMENTED YET)
%calc_approach = 'direct';
calc_approach = 'iterative';

% Flag that signals that conductance should be calculated.
% (Only possible when there are only two bulk objects present, one
% representing the emitter and one representing the absorber.  All emitter
% subvolumes must be at a constant temperature, and all absorber subvolumes
% must be at 0 K).
calc_conductance_bulk = 1;

% Flag that signals that conductance should be calculated.
% (Conductance is calculated between two specified subvolumes).
calc_conductance_subvol = 0;

% Conduct convergence analysis? (0 = "no", 1 = "yes")
convergence_analysis = 0;


%%%%%%%%%%%%%%%%%%%
% Load parameters %
%%%%%%%%%%%%%%%%%%%

% REQUIRED PARAMETERS:
%       geometry          String describing the geometry
%       material          String describing the material
%       r                 (N x 3) matrix containing points of all cubic lattice points [m]
%       ind_bulk 	      Indices of first subvolume in a given bulk object
%       delta_V_vector    (N x 1) vector of all subvolume sizes [m^3]
%       T_vector          (N x 1) vector of all subvolume temperatures [K]
%       omega             Frequency [rad/s] (must be a column vector)
%       epsilon           (N x 1) vector of all subvolume dielectric functions
%       epsilon_ref 	  Dielectric function of background reference medium


% Geometry and material descriptions
geometry = 'sphere';
material = 'SiO_2';

% What type of dielectric function input is used? ('analytical', 'empirical', 'thin_film', 'temp_dependent')
dielectric_option = 'analytical';
%dielectric_option = 'empirical';
%dielectric_option = 'thin_film';      % Only for SiC
%dielectric_option = 'temp_dependent'; % Only for SiC


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Cubic lattice discretization %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% The following code is for two spheres.  The user may change this section to
% upload discretizations for other geometries.

% Number of subvolumes per sphere (for perfect spheres)
% (1, 8, 32, 136, 280, 552, 912, 1472, 2176, 3112, 4224, 5616, 7208, 9328,
% 11536, 14328, 17256, 20672, 24464, 33552, 39024, 44720, 51104, 57856, 
% 65752, 73824, 82712, 92096, 113104, 137376, 212472, 268096, 210248, 382336)
N_sphere = 1;

% Directory where discretization is saved
%disc_directory = 'Input parameters/Discretization schemes/Perfect spheres';
disc_directory = 'Library/Discretizations/sphere';

shape_file_1 = ['sphere_' num2str(N_sphere) '.xlsx']; % Name of file for sphere 1
shape_file_2 = ['sphere_' num2str(N_sphere) '.xlsx']; % Name of file for sphere 2
L1 = 100e-9;                          % Diameter of the sphere [m]
L2 = 100e-9;                          % Diameter of the sphere [m]
d = 10e-9;                           % Distance between closest surfaces of bulk objects [m]
d_center = L1/2 + L2/2 + d;           % Center-of-mass separation distance
origin_1 = [L1/2,L1/2,L1/2];          % Origin of shape #1
origin_2 = origin_1 + [(L2 + d),0,0]; % Origin of shape #2
R1 = xlsread([disc_directory, '/', shape_file_1]); % Load discretized lattice for shape #1
R2 = xlsread([disc_directory, '/', shape_file_2]); % Load discretized lattice for shape #2
[N1, ~] = size(R1);                   % Number of subvolumes in shape #1
[N2, ~] = size(R2);                   % Number of subvolumes in shape #2
V_eq_sphere_1 = (4/3)*pi*((L1/2)^3);  % Volume of an equivalent sphere for shape #1
V_eq_sphere_2 = (4/3)*pi*((L2/2)^3);  % Volume of an equivalent sphere for shape #2
delta_V_1 = V_eq_sphere_1/N1;         % Scaling factor of shape #1
delta_V_2 = V_eq_sphere_2/N2;         % Scaling factor of shape #2
R1 = R1*(delta_V_1^(1/3)) + origin_1; % Scale shape #1 and move to proper origin
R2 = R2*(delta_V_2^(1/3)) + origin_2; % Scale shape #2 and move to proper origin
r = [R1; R2];                         % Complete discretized lattice [m]
[N,~] = size(r);                      % Determine total number of subvolumes

% Bulk object start index
ind_bulk = [1, N1+1];

% Vector of all subvolume sizes [m^3]
delta_V_vector = [delta_V_1*ones(1,N1), delta_V_2*ones(1,N2)]; % Volume of each subvolume (uniform subvolume size)
L_sub = delta_V_vector.^(1/3);                                 % Length of side of a cubic subvolume

% Temperature vector
T1 = 300;                          % Temperature of object 1 [K]
T2 = 800;                          % Temperature of object 2 [K]
T1_vector = T1*ones(N1,1);         % Assign temp to each subvolume of object 1 [K]
T2_vector = T2*ones(N2,1);         % Assign temp to each subvolume of object 2 [K]
T_vector = [T1_vector;T2_vector];  % (N x 1) vector of all subvolume temperatures [K]
T_conductance = T1;                % Temperature at which conductance will be calculated [K]

% Dielectric function of background reference medium
epsilon_ref = 1;

%****************************END USER INPUTS******************************%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%*********************CALCULATE DIELECTRIC FUNCTION***********************%

%%%%%%%%%%%%%%%%%%%%%%%%%%%
% SiO2 dielectric function %
%%%%%%%%%%%%%%%%%%%%%%%%%%%
if strcmp(material, 'SiO_2')
    
    % Bulk thermal conductivity value [W/m-K]
    kappa_bulk = 1.4;
    
    if strcmp(dielectric_option, 'analytical') % Analytical solution from Lorentz oscillator model
        
        % Radial frequency [rad/s]
        N_omega = 100;                      % Number of frequencies to evaluate
        %omega = linspace(4e12, 5e14, N_omega); % Radial frequency [rad/s]
        lambda = linspace(5e-6, 25e-6, N_omega);
        omega = 2*pi*c_0./lambda;
        E_joules = h_bar*omega;             % Wave energy [J]
        E_eV = E_joules./q;                 % Wave energy [eV]
        
        % Dielectric function of thermal objects
        epsilon = SiO2_dielectric_function(omega, constants); % (N x 1) vector of all dielectric functions for every frequency
        
    elseif strcmp(dielectric_option, 'empirical') % Empirical data
        
        % Import dielectric function data
        SiO2_excel_data = xlsread('Dielectric_function_silica.xlsx', 'Sheet1'); % Import Excel data for dielectric function of silica (SiO2)
        epsilon_real = SiO2_excel_data(:,5);      % Real part of dielectric function
        epsilon_imag = SiO2_excel_data(:,6);      % Imaginary part of dielectric function
        epsilon = epsilon_real + 1i*epsilon_imag; % (N x 1) vector of all subvolume dielectric functions
        epsilon = epsilon(1:79);              % TRUNCATE RANGE!
        
        % Radial frequency [rad/s]
        E_eV = SiO2_excel_data(:,1); % Wave energy [eV]
        E_joules = E_eV*q;           % Wave energy [J]
        omega = E_joules/h_bar;      % Angular frequency (E = h_bar*omega) [rad/s];
        omega = omega(1:79);     % TRUNCATE RANGE!
        N_omega = length(omega);     % Number of frequencies to evaluate
    end
    
end % End SiO2 dielectric function

%%%%%%%%%%%%%%%%%%%%%%%%%%%
% SiC dielectric function %
%%%%%%%%%%%%%%%%%%%%%%%%%%%
if strcmp(material, 'SiC')
    
    if strcmp(dielectric_option, 'analytical') % Analytical solution from Lorentz oscillator model
        
        % Radial frequency [rad/s]
        N_omega = 100;                      % Number of frequencies to evaluate
        omega = linspace(4e12, 5e14, N_omega); % Radial frequency [rad/s] THIS IS THE ONE WE USUALLY USE FOR THERMAL APPLICATIONS
        %omega = linspace(1e14, 2e14, N_omega); % Radial frequency [rad/s] (this is around the resonance mode)
        % lambda = linspace(5e-6, 25e-6, N_omega);
        % omega = 2*pi*c_0./lambda;
        E_joules = h_bar*omega;             % Wave energy [J]
        E_eV = E_joules./q;                 % Wave energy [eV]
        
        % Dielectric function of thermal objects
        epsilon = SiC_dielectric_function(omega); % (N x 1) vector of all dielectric functions for every frequency
        
    elseif strcmp(dielectric_option, 'thin_film') % Thin film model
        % Radial frequency [rad/s]
        N_omega = 100;                      % Number of frequencies to evaluate
        omega = linspace(4e12, 5e14, N_omega); % Radial frequency [rad/s] THIS IS THE ONE WE USUALLY USE FOR THERMAL APPLICATIONS
        %omega = linspace(1e14, 2e14, N_omega); % Radial frequency [rad/s] (this is around the resonance mode)
        % lambda = linspace(5e-6, 25e-6, N_omega);
        % omega = 2*pi*c_0./lambda;
        E_joules = h_bar*omega;             % Wave energy [J]
        E_eV = E_joules./q;                 % Wave energy [eV]
        
        % Dielectric function of thermal objects
        epsilon = SiC_thin_film_dielectric_function(omega); % (N x 1) vector of all dielectric functions for every frequency
        
    elseif strcmp(dielectric_option, 'temp_dependent') % Temperature dependent model
        
        N_omega = 100;                         % Number of frequencies to evaluate
        omega = linspace(4e12, 5e14, N_omega);  % Radial frequency [rad/s] THIS IS THE ONE WE USUALLY USE FOR THERMAL APPLICATIONS
        %omega = linspace(1e14, 2e14, N_omega); % Radial frequency [rad/s] (this is around the resonance mode)
        % lambda = linspace(5e-6, 25e-6, N_omega);
        % omega = 2*pi*c_0./lambda;
        E_joules = h_bar*omega;             % Wave energy [J]
        E_eV = E_joules./q;                 % Wave energy [eV]
        epsilon_matrix = zeros(N_omega, length(T_vector)); % Preallocate
        for T_loop = 1:length(T_vector)
            % Dielectric function of thermal objects
            epsilon_matrix(:,T_loop) = SiC_dielectric_function_temp_dependent(omega, T_vector(T_loop)); % (N x 1) vector of all dielectric functions for every frequency
        end
        
    elseif strcmp(dielectric_option, 'empirical') % Empirical data
        
    end
    
end % End SiC dielectric function

%%%%%%%%%%%%%%%%%%%%%%%%%%%
% SiN dielectric function %
%%%%%%%%%%%%%%%%%%%%%%%%%%%
if strcmp(material, 'SiN')
    
    %Bulk thermal conductivity value [W/m-K]
    kappa_bulk = 30; % I JUST FOUND THIS ONLINE! DOUBLE CHECK FROM PEER REVIEWED PAPER!
    
    if strcmp(dielectric_option, 'analytical') % Analytical solution from Lorentz oscillator model
        
        % Radial frequency [rad/s]
        N_omega = 100;                      % Number of frequencies to evaluate
        omega = linspace(50e12, 300e12, N_omega); % Radial frequency [rad/s] THIS IS THE ONE WE USUALLY USE FOR THERMAL APPLICATIONS
        % lambda = linspace(5e-6, 25e-6, N_omega);
        % omega = 2*pi*c_0./lambda;
        E_joules = h_bar*omega;             % Wave energy [J]
        E_eV = E_joules./q;                 % Wave energy [eV]
        
        % Dielectric function of thermal objects
        epsilon = SiN_dielectric_function(omega); % (N x 1) vector of all dielectric functions for every frequency
        
    elseif strcmp(dielectric_option, 'empirical') % Empirical data
        
        % Import dielectric function data
        SiN_excel_data = xlsread('SiN_dielectric_function.xlsx', 'Sheet1'); % Import Excel data for dielectric function of silica (SiO2)
        omega_real = SiN_excel_data(:,1);        % Frequencies corresponding to real part of dielectric function
        omega_imag = SiN_excel_data(1:178,4);        % Frequencies corresponding to real part of dielectric function
        epsilon_real = SiN_excel_data(:,2);      % Real part of dielectric function
        epsilon_imag = SiN_excel_data(1:178,5);      % Imaginary part of dielectric function
        
        % Remove duplicate points
        [omega_real, index_real] = unique(omega_real);
        [omega_imag, index_imag] = unique(omega_imag);
        
        N_omega = 204;                                           % Number of frequencies
        %omega = linspace(125e12, 225e12, N_omega);                % Set frequencies [rad/s]
        omega = linspace(50e12, 300e12, N_omega);                % Set frequencies [rad/s]
        epsilon_real = interp1(omega_real, epsilon_real(index_real), omega); % Interpolate to match frequencies
        epsilon_imag = interp1(omega_imag, epsilon_imag(index_imag), omega); % Interpolate to match frequencies
        
        omega = omega(3:end-2);
        epsilon = epsilon_real(3:end-2) + 1i*epsilon_imag(3:end-2); % (N x 1) vector of all subvolume dielectric functions
        N_omega = length(omega);
        
    end
end % End SiN dielectric function

%****************END CALCULATION OF DIELECTRIC FUNCTION*******************%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%***************************CHECK CONVERGENCE*****************************%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Check convergence criteria before proceeding %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if convergence_analysis == 1
    % Set tolerances
    tol_1 = 1;
    tol_2 = 6;
    tol_3 = 6;
    tol_4 = 6;
    tol_5 = 6;
    
    [ check_1, check_2, check_3, check_4, check_5,...
        omega_failed_2, N_failed_2, omega_failed_3, N_failed_3,...
        omega_failed_4, N_failed_4, omega_failed_5, N_failed_5 ] ...
        = convergence_check_function( delta_V_vector, d, omega, epsilon, epsilon_ref, tol_1, tol_2, tol_3, tol_4, tol_5 );
end % End convergence check

%*************************END CONVERGENCE CHECK***************************%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Plot dielectric function %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%

Fig_dielectric_function = figure(1);
semilogx(omega, real(epsilon), omega, imag(epsilon), '--', 'linewidth', 2)
%plot(lambda*1e6, real(epsilon), lambda*1e6, imag(epsilon), '--', 'linewidth', 2)
xlabel('Frequency [rad/s]', 'fontsize', 12)
%xlabel('Wavelength, \lambda [\mum]', 'fontsize', 12)
ylabel('Dielectric function, \epsilon', 'fontsize', 12)
title(['Dielectric function of ' material ', N_o_m_e_g_a = ' num2str(N_omega)], 'fontsize', 16)
legend('Real part', 'Imaginary part', 'location', 'best')
set(gca, 'fontsize', 16)
axis tight
grid on


%%%%%%%%%%%%%%%%%%%%%%%
% Plot discretization %
%%%%%%%%%%%%%%%%%%%%%%%

% Visualize discretized lattice
Fig_discretization = figure(2);
plot3(r(:,1), r(:,2), r(:,3), 'x')
title(['Location of each subvolume for N = ', num2str(N), ' total subvolumes'], 'fontsize', 14)
xlabel('x-axis [m]')
ylabel('y-axis [m]')
zlabel('z-axis [m]')
set(gca, 'Fontsize', 20)
set(gca,'DataAspectRatio',[1 1 1])
view(3)
grid on
hold on

% Save discretization figure file
if save_fig == 1
    fig_path_2 = [saveDir '/' file_name_saved '_discretization.fig'];
    saveas(Fig_discretization, fig_path_2)
    clear Fig_dielectric_function Fig_discretization % Remove previous plot handles
end


% Plot voxel image of discretization
FIG_voxel = figure(3);
[vert, fac] = voxel_image( r, L_sub(1), [], [], [], [], 'on', [], [] );
xlabel('x-axis (m)');
ylabel('y-axis (m)');
zlabel('z-axis (m)');
if show_axes == 0
    grid off
    axis off
    set(gca, 'fontsize', 30)
end
%view(35,20)
view(5,20)
%view(2)

% Save voxel discretization figure file
if save_fig == 1
    fig_path_3 = [saveDir '/' file_name_saved '_voxelDiscretization.fig'];
    saveas(FIG_voxel, fig_path_3)
    clear FIG_voxel % Remove previous plot handles
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Calculate DSGF and power dissipation %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Preallocate vectors
G_omega = zeros(N_omega,1);
G_omega_eV = zeros(N_omega,1);
Trans_omega_12 = zeros(N_omega,1);
Trans_omega_13 = zeros(N_omega,1);
Trans_lambda_12 = zeros(N_omega,1);
Trans_lambda_13 = zeros(N_omega,1);
Q_omega_bulk = zeros(N_omega, length(ind_bulk));
Q_omega_subvol = zeros(N_omega, N);

for omega_loop = 1:N_omega % Loop through all frequencies
    
    % Add space in Command Window
    disp(' ')
    
    % Record time at start of frequency loop
    t1 = toc;
    
    if strcmp(calc_approach, 'direct') % Direct matrix inversion approach
        
        [ G_sys_2D, Trans, Q_omega_bulk(omega_loop, :), Q_omega_subvol(omega_loop, :),G_0_2D  ] = direct_function(omega(omega_loop), r, epsilon(omega_loop)*ones(1,N), epsilon_ref, delta_V_vector, T_vector, ind_bulk);
        
    elseif strcmp(calc_approach, 'iterative') % Iterative solver from Martin et al. 1995 paper
        
        [G_sys_2D_iterative, Trans, Q_omega_bulk(omega_loop, :), Q_omega_subvol(omega_loop, :)] = iterative_function_Martin_1995(omega(omega_loop), r, epsilon(omega_loop)*ones(1,N), epsilon_ref, delta_V_vector, T_vector, ind_bulk);
        
        
        
    end % End direct vs. iterative approach
    
    
    % Calculate spectral transmission coefficient between object 1 and object 2 [dimensionless]
    Trans_omega_12(omega_loop) = trans_coeff_function_bulk( Trans, ind_bulk, 1, 2 );
    
    % Convert transmission coefficient for bulk objects into units of per
    % wavelength (rather than frequency) [1/(s*m)]
    %Trans_lambda_12(omega_loop) = Trans_omega_12(omega_loop)*(omega(omega_loop)^2)/(((2*pi)^2)*c_0);
    %Trans_lambda_13(omega_loop) = Trans_omega_13(omega_loop)*(omega(omega_loop)^2)/(((2*pi)^2)*c_0);
    
        
    %%%%%%%%%%%%%%%%
    % Save results %
    %%%%%%%%%%%%%%%%
    
    % Save all workspace variables
    %if save_var_mat == 1
    %    save([saveDir, '/', file_name_saved])
    %end
    
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Print status to Command window %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % End time for one frequency loop
    t2 = toc;
    
    % Print time for one frequency loop
    disp(['t = ' num2str(t2-t1) ' seconds = ' num2str((t2-t1)/60) ' minutes for one frequency loop'])
    
    % Print frequencies remaining to Command Window
    disp([num2str(length(omega) - omega_loop) ' frequencies remaining'])
    
  
end % End loop through all frequencies


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Calculate spectral and total conductance at temperature, T_conductance %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% If flag signals that conductance should be calculated between bulk
% objects.
if calc_conductance_bulk == 1

    [ G_omega_bulk_12, G_bulk_12 ] = conductance_bulk( Trans_omega_12, T_conductance, omega.' );


    % Plot spectral conductance vs. frequency
    FIG_14 = figure(14)
    semilogy(omega, G_omega_bulk_12, '-x', 'linewidth', 2)
    %plot(E_eV, G_omega_eV.', '-x', 'linewidth', 2)
    xlabel('Frequency [rad/s]')
    ylabel('Spectral conductance, G_\omega  [WK^-^1(rad/s)^-^1]', 'fontsize', 12)
    title([material ', ' geometry ', D = ' num2str(L1*(10^6)) '\mum, d = '...
        num2str(d*(10^6)) '\mum, ' num2str(N_omega) ' frequencies, N = ' num2str(N) ' total subvolumes'], 'fontsize', 16)
    axis tight
    set(gca, 'fontsize', 22)
    %legend([num2str(N(1)/2) ' subvolumes'], 'location', 'best')
    grid on

    % Save figure files
    if save_fig == 1
        fig_path_14 = [saveDir '/' file_name_saved '_spectralConductance.fig'];
        saveas(FIG_14, fig_path_14)
    end

end % End conductance calculations

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Calculate total heat dissipation in each subvolume %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Total heat dissipated in a subvolume [W]
Q_total_subvol = zeros(1,N); % Preallocate
for ii = 1:N
    Q_total_subvol(ii) = trapz(omega, Q_omega_subvol(:,ii));  % Heat dissipated in each subvolume [W]
end

% Total heat density dissipated in a subvolume [W/(m^3)]
Q_density_subvol = Q_total_subvol./delta_V_vector; % Heat density dissipated in each subvolume [W/(m^3)]

% Restructure heat dissipated in a subvolume from a vector to a matrix with
% indices of coordinates intact
Q_total_subvol_matrix = [r, Q_total_subvol.'];

%%%%%%%%%%%%%%%%
% Save results %
%%%%%%%%%%%%%%%%

% Save all workspace variables
if save_var_mat == 1
    save([saveDir, '/', file_name_saved])
end


%% 
%%%%%%%%%%%%%%%%%%
% Plot heat maps %
%%%%%%%%%%%%%%%%%%

% XY-PLANE CUT: Find locations and indices for particle halves cut down the middle (cut along the xy-plane)
r_z_avg = (max(r(:,3)) + min(r(:,3)))/2;
ind_half_xy = find(r(:,3) >= r_z_avg);
r_half_xy = r(ind_half_xy, :);
Q_total_subvol_half_xy = Q_total_subvol(ind_half_xy);
%{
% XY-PLANE CUT: Plot subvolume locations of particle halves cut down the middle (cut along the xy-plane)
FIG_4 = figure(4);
plot3(r_half_xy(:,1), r_half_xy(:,2), r_half_xy(:,3), 'x')
xlabel('x-axis [m]');
ylabel('y-axis [m]');
zlabel('z-axis [m]');
set(gca, 'Fontsize', 16)
axis equal
grid on


% XZ-PLANE CUT: Find locations and indices for particle halves cut down the middle (cut along the xz-plane)
r_y_avg = (max(r(:,2)) + min(r(:,2)))/2;
ind_half_xz = find(r(:,2) >= r_y_avg);
r_half_xz = r(ind_half_xz, :);
Q_total_subvol_half_xz = Q_total_subvol(ind_half_xz);

% XZ-PLANE CUT: Plot subvolume locations of particle halves cut down the middle (cut along the xz-plane)
FIG_5 = figure(5);
plot3(r_half_xz(:,1), r_half_xz(:,2), r_half_xz(:,3), 'x')
xlabel('x-axis [m]');
ylabel('y-axis [m]');
zlabel('z-axis [m]');
set(gca, 'Fontsize', 16)
axis equal
grid on



% XY-PLANE CUT: Find locations and indices of a single slice (one subvolume thick)
ind_slice_xy = find((r(:,3) >= r_z_avg) & (r(:,3) <= r_z_avg + L_sub(1)));
r_slice_xy = r(ind_slice_xy, :);
Q_total_subvol_slice_xy = Q_total_subvol(ind_slice_xy);

% XY-PLANE CUT: Plot subvolume locations of a single slice (one subvolume thick)
FIG_6 = figure(6);
plot3(r_slice_xy(:,1), r_slice_xy(:,2), r_slice_xy(:,3), 'x')
xlabel('x-axis [m]');
ylabel('y-axis [m]');
zlabel('z-axis [m]');
set(gca, 'Fontsize', 16)
axis equal
grid on
view(2)
%set(gca,'DataAspectRatio',[1 1 1])



% XZ-PLANE CUT: Find locations and indices of a single slice (one subvolume thick)
ind_slice_xz = find((r(:,2) >= r_y_avg) & (r(:,2) <= r_y_avg + L_sub(1)));
r_slice_xz = r(ind_slice_xz, :);
Q_total_subvol_slice_xz = Q_total_subvol(ind_slice_xz);

% XZ-PLANE CUT: Plot subvolume locations of a single slice (one subvolume thick)
FIG_7 = figure(7);
plot3(r_slice_xz(:,1), r_slice_xz(:,2), r_slice_xz(:,3), 'x')
xlabel('x-axis [m]');
ylabel('y-axis [m]');
zlabel('z-axis [m]');
set(gca, 'Fontsize', 16)
axis equal
grid on
view(2)
%set(gca,'DataAspectRatio',[1 1 1])
%}

% Set heatmap color axis limits
abs_limit = max(abs(Q_total_subvol));
c_limits = [-abs_limit, abs_limit];
%c_limits = [min(Q_total_subvol), max(Q_total_subvol)];


%%

%close all

% Subvolume heat map for full particles (VIEW 1)
FIG_8 = figure(8);
%subplot(1,2,1)
%[vert, fac] = voxel_image( r(1:N1,:), L_sub(1), [], [], [], [], 'heatmap', Q_total_subvol(1:N1).' ); % Absorber (T = 0 K)
%[vert, fac] = voxel_image( r(N1+1:end,:), L_sub(1), [], [], [], [], 'heatmap', Q_total_subvol(N1+1:end).' ); % Emitter (T = 300 K)
[vert, fac] = voxel_image( r, L_sub(1), [], [], [], [], 'heatmap', Q_total_subvol.', c_limits );
xlabel('x-axis (m)');
ylabel('y-axis (m)');
zlabel('z-axis (m)');
if show_axes == 0
    grid off
    axis off
    colorbar off
end
%view(2)
view(-30,35)

% Subvolume heat map for full particles (VIEW 2)
FIG_9 = figure(9);
%subplot(1,2,2)
%[vert, fac] = voxel_image( r(1:N1,:), L_sub(1), [], [], [], [], 'heatmap', Q_total_subvol(1:N1).' ); % Absorber (T = 0 K)
%[vert, fac] = voxel_image( r(N1+1:end,:), L_sub(1), [], [], [], [], 'heatmap', Q_total_subvol(N1+1:end).' ); % Emitter (T = 300 K)
[vert, fac] = voxel_image( r, L_sub(1), [], [], [], [], 'heatmap', Q_total_subvol.', c_limits );
xlabel('x-axis (m)');
ylabel('y-axis (m)');
zlabel('z-axis (m)');
if show_axes == 0
    grid off
    axis off
    %cb = colorbar;
    %colorbar('east')
    %set(cb,'position',[0.2 0.2 .05 .5]) % [xposition yposition width height].
    set(gca, 'fontsize', 30)
end
view(35,20)


%{

%%
% XY-PLANE CUT: Subvolume heat map for half particles
FIG_10 = figure(10);
%[vert, fac] = voxel_image( r(1:N1,:), L_sub(1), [], [], [], [], 'heatmap', Q_total_subvol(1:N1).' ); % Absorber (T = 0 K)
%[vert, fac] = voxel_image( r(N1+1:end,:), L_sub(1), [], [], [], [], 'heatmap', Q_total_subvol(N1+1:end).' ); % Emitter (T = 300 K)
[vert, fac] = voxel_image( r_half_xy, L_sub(1), [], [], [], [], 'heatmap', Q_total_subvol_half_xy.', c_limits );
%view(2)



% XY-PLANE CUT: Subvolume heat map for slices of particles
FIG_11 = figure(11);
%[vert, fac] = voxel_image( r(1:N1,:), L_sub(1), [], [], [], [], 'heatmap', Q_total_subvol(1:N1).' ); % Absorber (T = 0 K)
%[vert, fac] = voxel_image( r(N1+1:end,:), L_sub(1), [], [], [], [], 'heatmap', Q_total_subvol(N1+1:end).' ); % Emitter (T = 300 K)
[vert, fac] = voxel_image( r_slice_xy, L_sub(1), [], [], [], [], 'heatmap', Q_total_subvol_slice_xy.', c_limits );
%view(2)

% XZ-PLANE CUT: Subvolume heat map for half particles
FIG_12 = figure(12);
%[vert, fac] = voxel_image( r(1:N1,:), L_sub(1), [], [], [], [], 'heatmap', Q_total_subvol(1:N1).' ); % Absorber (T = 0 K)
%[vert, fac] = voxel_image( r(N1+1:end,:), L_sub(1), [], [], [], [], 'heatmap', Q_total_subvol(N1+1:end).' ); % Emitter (T = 300 K)
[vert, fac] = voxel_image( r_half_xz, L_sub(1), [], [], [], [], 'heatmap', Q_total_subvol_half_xz.', c_limits );
%view(2)

% XZ-PLANE CUT: Subvolume heat map for slices of particles
FIG_13 = figure(13);
%[vert, fac] = voxel_image( r(1:N1,:), L_sub(1), [], [], [], [], 'heatmap', Q_total_subvol(1:N1).' ); % Absorber (T = 0 K)
%[vert, fac] = voxel_image( r(N1+1:end,:), L_sub(1), [], [], [], [], 'heatmap', Q_total_subvol(N1+1:end).' ); % Emitter (T = 300 K)
[vert, fac] = voxel_image( r_slice_xz, L_sub(1), [], [], [], [], 'heatmap', Q_total_subvol_slice_xz.', c_limits );
%view(2)

%}

% Save figure files
if save_fig == 1
    %fig_path_4 = [saveDir '/' file_name_saved '_discretization_xy_half.fig'];
    %fig_path_5 = [saveDir '/' file_name_saved '_discretization_xz_half.fig'];
    %fig_path_6 = [saveDir '/' file_name_saved '_discretization_xy_slice.fig'];
    %fig_path_7 = [saveDir '/' file_name_saved '_discretization_xz_slice.fig'];
    fig_path_8 = [saveDir '/' file_name_saved '_heatmap_full_view1.fig'];
    %fig_path_9 = [saveDir '/' file_name_saved '_heatmap_full_view2.fig'];
    %fig_path_10 = [saveDir '/' file_name_saved '_heatmap_xy_half.fig'];
    %fig_path_11 = [saveDir '/' file_name_saved '_heatmap_xy_slice.fig'];
    %fig_path_12 = [saveDir '/' file_name_saved '_heatmap_xz_half.fig'];
    %fig_path_13 = [saveDir '/' file_name_saved '_heatmap_xz_slice.fig'];
    %saveas(FIG_4, fig_path_4)
    %saveas(FIG_5, fig_path_5)
    %saveas(FIG_6, fig_path_6)
    %saveas(FIG_7, fig_path_7)
    saveas(FIG_8, fig_path_8)
    %saveas(FIG_9, fig_path_9)
    %saveas(FIG_10, fig_path_10)
    %saveas(FIG_11, fig_path_11)
    %saveas(FIG_12, fig_path_12)
    %saveas(FIG_13, fig_path_13)
end



%%





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Print status to Command Window %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% Print out workspace memory required (the following lines come from Eric's
% code)
vars = struct2cell(whos);
workspaceMem = sum(cell2mat(vars(3,:)))/1e9;
disp('----------------------------------------------------------------')
disp(['Workspace memory required is ', num2str(workspaceMem), ' GB'])
disp('')
disp('----------------------------------------------------------------')
memory


timeElapsed = toc

% View output from profiler
%profile viewer