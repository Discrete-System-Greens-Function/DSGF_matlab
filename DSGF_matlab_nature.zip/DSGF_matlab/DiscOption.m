classdef DiscOption
	enumeration
		sample, user
	end
end
